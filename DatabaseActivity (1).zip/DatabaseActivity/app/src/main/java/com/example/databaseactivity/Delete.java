package com.example.databaseactivity;

public class Delete {
}
